import pandas as pd

# Load the dataset and keep the custom student labels as the index
df = pd.read_csv("student_selection.csv", index_col=0)

print("FULL DATAFRAME")
print(df)

# =========================================================
# LOC[] — LABEL-BASED SELECTION
# =========================================================

# 1. One complete row by label
print("\nLOC 1")
print(df.loc["S001"])

# 2. Several complete rows by labels
print("\nLOC 2")
print(df.loc[["S002", "S004", "S006"]])

# 3. One row + one column
print("\nLOC 3")
print(df.loc["S003", "Python_Marks"])

# 4. Several rows + one column
print("\nLOC 4")
print(df.loc[["S001", "S003", "S005"], "Python_Marks"])

# 5. Several rows + several named columns
print("\nLOC 5")
print(df.loc[
    ["S002", "S004", "S006"],
    ["Name", "SQL_Marks", "Attendance"]
])

# 6. Label range + selected columns
print("\nLOC 6")
print(df.loc[
    "S002":"S005",
    ["Name", "Python_Marks", "Average"]
])

# 7. All rows + selected columns
print("\nLOC 7")
print(df.loc[:, ["Name", "Average"]])

# 8. Conditional selection
print("\nLOC 8")
print(df.loc[df["Average"] >= 80, ["Name", "Average"]])

# 9. Multiple conditions
print("\nLOC 9")
print(df.loc[
    (df["Average"] >= 80) & (df["Attendance"] >= 85),
    ["Name", "Average", "Attendance"]
])

# =========================================================
# ILOC[] — POSITION-BASED SELECTION
# =========================================================

# 1. First row
print("\nILOC 1")
print(df.iloc[0])

# 2. Several rows by positions
print("\nILOC 2")
print(df.iloc[[1, 3, 5]])

# 3. One cell: row position 2, column position 3
print("\nILOC 3")
print(df.iloc[2, 3])

# 4. Row positions + selected column positions
print("\nILOC 4")
print(df.iloc[1:5, [1, 3, 4]])

# 5. Rectangular block
print("\nILOC 5")
print(df.iloc[2:6, 1:5])

# 6. Last two rows
print("\nILOC 6")
print(df.iloc[-2:])

# 7. First three rows and first four columns
print("\nILOC 7")
print(df.iloc[:3, :4])

# 8. Every second row
print("\nILOC 8")
print(df.iloc[::2])

# =========================================================
# COMPARISON
# =========================================================
print("\nKEY RULE")
print("loc[]  -> labels")
print("iloc[] -> integer positions")

# Practical result
print("\nHIGH-PERFORMING STUDENTS")
print(df.loc[
    df["Average"] >= 85,
    ["Name", "Python_Marks", "SQL_Marks", "Average"]
])
